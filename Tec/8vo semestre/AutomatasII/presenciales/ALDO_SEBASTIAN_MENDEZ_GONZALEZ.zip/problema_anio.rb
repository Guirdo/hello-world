=begin

Escribir un programa que diga cuantos minutos hay en un año

=end

dias = 365
horas = 24
minutosHora = 60

puts dias*horas*minutosHora